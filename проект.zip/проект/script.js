
/* =================================
   FORMA FASHION STORE
   СПИСОК ТОВАРОВ
================================= */

const products = [

    {
        id: 1,
        name: "Пиджак прямого кроя",
        category: "Женская",
        price: 32900,
        tag: "БЕСТСЕЛЛЕР",
        image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 2,
        name: "Базовая футболка",
        category: "Мужская",
        price: 12900,
        tag: "NEW",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 3,
        name: "Платье Soft Line",
        category: "Женская",
        price: 27900,
        tag: "NEW",
        image: "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 4,
        name: "Рубашка свободная",
        category: "Мужская",
        price: 21900,
        tag: "",
        image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 5,
        name: "Тренч Everyday",
        category: "Женская",
        price: 45900,
        tag: "LIMITED",
        image: "https://images.unsplash.com/photo-1548126032-079a0fb0099d?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 6,
        name: "Свитшот Essential",
        category: "Мужская",
        price: 24900,
        tag: "",
        image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 7,
        name: "Сумка Mini Form",
        category: "Аксессуары",
        price: 19900,
        tag: "NEW",
        image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 8,
        name: "Джинсы Straight",
        category: "Женская",
        price: 26900,
        tag: "",
        image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 9,
        name: "Куртка Urban",
        category: "Мужская",
        price: 38900,
        tag: "",
        image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 10,
        name: "Очки Studio",
        category: "Аксессуары",
        price: 14900,
        tag: "",
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 11,
        name: "Топ Minimal",
        category: "Женская",
        price: 9900,
        tag: "",
        image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=85"
    },

    {
        id: 12,
        name: "Кросс-боди сумка",
        category: "Аксессуары",
        price: 22900,
        tag: "NEW",
        image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=85"
    }

];


/* =================================
   СОХРАНЕНИЕ ДАННЫХ
================================= */

// Корзина
let cart = JSON.parse(
    localStorage.getItem("forma-fashion-cart") || "{}"
);

// Избранное
let favorites = JSON.parse(
    localStorage.getItem("forma-fashion-favorites") || "[]"
);

// Активная категория
let activeFilter = "all";

// Режим избранного
let favoritesOnly = false;


/* =================================
   ЭЛЕМЕНТЫ САЙТА
================================= */

const grid = document.getElementById("productGrid");

const cartOverlay = document.getElementById("cartOverlay");

const toastEl = document.getElementById("toast");


/* =================================
   ФОРМАТИРОВАНИЕ ЦЕНЫ
================================= */

const money = number => {

    return new Intl.NumberFormat("ru-RU")
        .format(number) + " ₸";

};


/* =================================
   УВЕДОМЛЕНИЯ
================================= */

function toast(message) {

    toastEl.textContent = message;

    toastEl.classList.add("show");

    clearTimeout(toastEl._timer);

    toastEl._timer = setTimeout(() => {

        toastEl.classList.remove("show");

    }, 2200);

}


/* =================================
   ОТОБРАЖЕНИЕ ТОВАРОВ
================================= */

function renderProducts() {

    const query = document
        .getElementById("searchInput")
        .value
        .trim()
        .toLowerCase();


    // Фильтрация товаров

    let list = products.filter(product => {

        const matchesCategory =
            activeFilter === "all" ||
            product.category === activeFilter;

        const matchesSearch =
            product.name.toLowerCase().includes(query) ||
            product.category.toLowerCase().includes(query);

        const matchesFavorites =
            !favoritesOnly ||
            favorites.includes(product.id);

        return (
            matchesCategory &&
            matchesSearch &&
            matchesFavorites
        );

    });


    // Сортировка

    const sort = document
        .getElementById("sortSelect")
        .value;

    if (sort === "low") {

        list.sort((a, b) => a.price - b.price);

    }

    if (sort === "high") {

        list.sort((a, b) => b.price - a.price);

    }


    // Создание карточек

    grid.innerHTML = list.map(product => `

        <article class="product-card">

            <div class="product-image">

                <img
                    src="${product.image}"
                    alt="${product.name}"
                    loading="lazy"
                >

                ${
                    product.tag
                    ? `<span class="product-tag">${product.tag}</span>`
                    : ""
                }

                <button
                    class="heart ${
                        favorites.includes(product.id) ? "active" : ""
                    }"
                    data-fav="${product.id}"
                >
                    ${
                        favorites.includes(product.id) ? "♥" : "♡"
                    }
                </button>

                <button
                    class="quick-add"
                    data-add="${product.id}"
                >
                    ДОБАВИТЬ В СУМКУ +
                </button>

            </div>


            <div class="product-meta">

                <div>

                    <div class="product-name">
                        ${product.name}
                    </div>

                    <div class="product-category">
                        ${
                            product.category === "Женская"
                            ? "ЖЕНСКАЯ КОЛЛЕКЦИЯ"
                            : product.category === "Мужская"
                            ? "МУЖСКАЯ КОЛЛЕКЦИЯ"
                            : "АКСЕССУАРЫ"
                        }
                    </div>

                </div>

                <div class="product-price">
                    ${money(product.price)}
                </div>

            </div>

        </article>

    `).join("");


    // Количество товаров

    document.getElementById("resultCount")
        .textContent = `${list.length} ПОЗИЦИЙ`;


    // Если ничего не найдено

    document.getElementById("noResults")
        .hidden = list.length !== 0;

}


/* =================================
   СОХРАНЕНИЕ КОРЗИНЫ
================================= */

function saveCart() {

    localStorage.setItem(
        "forma-fashion-cart",
        JSON.stringify(cart)
    );

    renderCart();

}


/* =================================
   ДОБАВЛЕНИЕ ТОВАРА В КОРЗИНУ
================================= */

grid.addEventListener("click", function(event) {

    const addButton = event.target.closest("[data-add]");

    const favButton = event.target.closest("[data-fav]");


    // Добавление товара

    if (addButton) {

        const id = Number(addButton.dataset.add);

        cart[id] = (cart[id] || 0) + 1;

        saveCart();

        toast("Добавлено в твою сумку ✳");

    }


    // Добавление в избранное

    if (favButton) {

        const id = Number(favButton.dataset.fav);

        if (favorites.includes(id)) {

            favorites = favorites.filter(
                item => item !== id
            );

        } else {

            favorites.push(id);

        }

        localStorage.setItem(
            "forma-fashion-favorites",
            JSON.stringify(favorites)
        );

        renderProducts();

    }

});


/* =================================
   ОТОБРАЖЕНИЕ КОРЗИНЫ
================================= */

function renderCart() {

    const entries = Object.entries(cart)
        .filter(([, qty]) => qty > 0);


    // Общее количество

    const count = entries.reduce(
        (sum, [, qty]) => sum + qty,
        0
    );


    document.getElementById("cartCount")
        .textContent = count;

    document.getElementById("drawerCount")
        .textContent = `(${count})`;


    let total = 0;


    // Пустая корзина

    if (entries.length === 0) {

        document.getElementById("cartItems").innerHTML = `

            <div class="cart-empty">

                ТВОЯ СУМКА ПОКА ПУСТА

                <br>

                Самое время найти что-то особенное ✳

            </div>

        `;

    } else {


        // Товары в корзине

        document.getElementById("cartItems").innerHTML =

            entries.map(([id, qty]) => {

                const product = products.find(
                    item => item.id === Number(id)
                );

                if (!product) return "";

                total += product.price * qty;


                return `

                    <div class="cart-row">

                        <img
                            src="${product.image}"
                            alt="${product.name}"
                        >

                        <div>

                            <b>${product.name}</b>

                            <small>
                                ${money(product.price)}
                            </small>

                            <div class="qty">

                                <button data-minus="${product.id}">
                                    −
                                </button>

                                <span>${qty}</span>

                                <button data-plus="${product.id}">
                                    +
                                </button>

                            </div>

                        </div>

                        <button
                            class="remove"
                            data-remove="${product.id}"
                        >
                            ×
                        </button>

                    </div>

                `;

            }).join("");

    }


    // Общая стоимость

    document.getElementById("cartTotal")
        .textContent = money(total);


    // Кнопка оформления

    document.getElementById("checkout")
        .disabled = count === 0;


    // Бесплатная доставка от 30 000 ₸

    const left = Math.max(0, 30000 - total);

    document.getElementById("shippingNote")
        .textContent = left === 0
        ? "Отлично! Доставка за наш счёт ✳"
        : `Добавь ещё на ${money(left)} для бесплатной доставки`;

}


/* =================================
   ИЗМЕНЕНИЕ КОЛИЧЕСТВА
================================= */

document.getElementById("cartItems")
    .addEventListener("click", function(event) {

        const button = event.target.closest("button");

        if (!button) return;


        const id = Number(

            button.dataset.plus ||
            button.dataset.minus ||
            button.dataset.remove

        );

        if (!id) return;


        // Увеличение

        if (button.dataset.plus) {

            cart[id] = (cart[id] || 0) + 1;

        }


        // Уменьшение

        if (button.dataset.minus) {

            cart[id] = Math.max(
                0,
                (cart[id] || 0) - 1
            );

        }


        // Удаление

        if (button.dataset.remove || cart[id] === 0) {

            delete cart[id];

        }


        saveCart();

    });


/* =================================
   ФИЛЬТРЫ КАТЕГОРИЙ
================================= */

document.getElementById("filters")
    .addEventListener("click", function(event) {

        const button = event.target.closest("[data-filter]");

        if (!button) return;


        activeFilter = button.dataset.filter;

        favoritesOnly = false;


        document.getElementById("showFavorites")
            .classList.remove("selected");


        document.querySelectorAll(".filter")
            .forEach(item => {

                item.classList.toggle(
                    "active",
                    item === button
                );

            });


        renderProducts();

    });


/* =================================
   КАТЕГОРИИ НА ГЛАВНОЙ СТРАНИЦЕ
================================= */

document.querySelectorAll("[data-category]")
    .forEach(tile => {

        tile.addEventListener("click", function() {

            activeFilter = tile.dataset.category;

            favoritesOnly = false;


            document.querySelectorAll(".filter")
                .forEach(item => {

                    item.classList.toggle(
                        "active",
                        item.dataset.filter === activeFilter
                    );

                });


            renderProducts();

        });

    });


/* =================================
   МЕНЮ НАВИГАЦИИ
================================= */

document.querySelectorAll("[data-nav]")
    .forEach(link => {

        link.addEventListener("click", function() {

            activeFilter = link.dataset.nav;

            favoritesOnly = false;


            document.querySelectorAll(".filter")
                .forEach(item => {

                    item.classList.toggle(
                        "active",
                        item.dataset.filter === activeFilter
                    );

                });


            renderProducts();

        });

    });


/* =================================
   ИЗБРАННОЕ
================================= */

document.getElementById("showFavorites")
    .addEventListener("click", function() {

        favoritesOnly = !favoritesOnly;

        activeFilter = "all";


        document.querySelectorAll(".filter")
            .forEach(item => {

                item.classList.toggle(
                    "active",
                    item.dataset.filter === "all"
                );

            });


        this.classList.toggle(
            "selected",
            favoritesOnly
        );


        renderProducts();


        document.getElementById("catalog")
            .scrollIntoView({
                behavior: "smooth"
            });

    });


/* =================================
   ПОИСК
================================= */

document.getElementById("searchToggle")
    .addEventListener("click", function() {

        const panel = document.getElementById("searchPanel");

        panel.classList.toggle("open");


        if (panel.classList.contains("open")) {

            document.getElementById("searchInput").focus();

        }

    });


document.getElementById("closeSearch")
    .addEventListener("click", function() {

        document.getElementById("searchPanel")
            .classList.remove("open");

    });


document.getElementById("searchInput")
    .addEventListener("input", renderProducts);


/* =================================
   СОРТИРОВКА
================================= */

document.getElementById("sortSelect")
    .addEventListener("change", renderProducts);


/* =================================
   ОТКРЫТИЕ КОРЗИНЫ
================================= */

document.getElementById("openCart")
    .addEventListener("click", function() {

        cartOverlay.classList.add("open");

    });


/* =================================
   ЗАКРЫТИЕ КОРЗИНЫ
================================= */

document.getElementById("closeCart")
    .addEventListener("click", function() {

        cartOverlay.classList.remove("open");

    });


cartOverlay.addEventListener("click", function(event) {

    if (event.target === cartOverlay) {

        cartOverlay.classList.remove("open");

    }

});


document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {

        cartOverlay.classList.remove("open");

    }

});


/* =================================
   ОФОРМЛЕНИЕ ЗАКАЗА
================================= */

document.getElementById("checkout")
    .addEventListener("click", function() {

        toast(
            "Демо-магазин: подключи оформление заказа для реальных покупок."
        );

    });


/* =================================
   ПОДПИСКА
================================= */

document.getElementById("newsletterForm")
    .addEventListener("submit", function(event) {

        event.preventDefault();

        document.getElementById("newsletterMessage")
            .textContent =
            "Спасибо! Подписка в демо-режиме оформлена.";

        this.reset();

    });


/* =================================
   МОБИЛЬНОЕ МЕНЮ
================================= */

document.getElementById("menuToggle")
    .addEventListener("click", function() {

        document.getElementById("mainNav")
            .classList.toggle("open");

    });


/* =================================
   ЗАПУСК МАГАЗИНА
================================= */

renderProducts();

renderCart();
